---
name: cmux-orchestrator
description: "Use when orchestrating multiple AI surfaces via cmux — v9.0 + 8-Stage Pipeline + MCP Deferred Loading + Merge-Judge(Sonnet) + Work-Logger(Haiku) + Peer Recognition(watcher=colleague) + autoresearch loop + GATE 1-14.6. Main=orchestrator(no code edits), workers=direct implementation(no subagents). Worktree parallel. 3-10min task units."
user-invocable: true
classification: workflow
allowed-tools: Bash, Read, Write, Grep, Glob, Agent, AskUserQuestion
---

# cmux Multi-AI Orchestrator v8.0

> v7.8: surface-dispatcher.sh workspace auto-resolve, commands/cmux.md --workspace batch fix | v7.7: GATE 14.5 send timeout retry, empty read-screen handling | v7.6: GATE 11 recovery procedure documented, cmux screenshot warning added | v7.5: DONE x2 output, worktree parallel, Main no code edits, workers no subagents, 3-10min task units, DONE confirm→/new protocol, GATE 9 set-buffer mandatory, Sonnet 4.6 surface added

**Improvement History:**
| Version | Changes | Date |
|------|------|------|
| v9.0 | 8-Stage Pipeline, Model-Specific Tool Loading, Merge-Judge(Sonnet), Work-Logger(Haiku), Peer Recognition(watcher=colleague) | 2026-03-27 |
| v8.0 | Orchestration specialization: autoresearch loop integration, 21 new cmux commands added, monitoring cmux-watcher separated and delegated | 2026-03-26 |
| v7.10 | workspace-resolver v2 (surface_exists validation), surface-dispatcher v8 (error handling, NOT_FOUND/NO_WS states), read-surface v2 (cmux check, error hints) | 2026-03-26 |
| v7.9 | English transition - remaining Korean text converted | 2026-03-26 |
| v7.8 | surface-dispatcher.sh workspace auto-resolve, commands/cmux.md --workspace batch fix | 2026-03-26 |
| v7.7 | GATE 14.5 send timeout retry, empty read-screen handling | 2026-03-26 |
| v7.6 | GATE 11 recovery procedure documented, cmux screenshot warning added | 2026-03-26 |
| v7.5 | DONE x2 output, worktree parallel, Main no code edits, workers no subagents, 3-10min task units, DONE confirm→/new protocol, GATE 9 set-buffer mandatory, Sonnet 4.6 surface added | 2026-03-25 |
| v7.4 | Version update | 2026-03-XX |

**Path variables** (portability):
- `${SKILL_DIR}` = this skill's root directory (e.g., `~/.claude/skills/cmux-orchestrator/`)
- `$CLAUDE_PLUGIN_ROOT` = plugin root (use if available, otherwise project root)

> Packaged file list: see `${SKILL_DIR}/references/` directory.

## ⚡ Startup Sequence + ⛔ Socket Overload Prevention (GATE 15)

> Details: `${SKILL_DIR}/references/startup-and-socket.md`

- **Startup sequence:** Workers → Watcher → Main (Orchestrator) order is MANDATORY
- **Parallel `cmux read-screen` strictly prohibited** → use `detect-surface-models.py` (0.3s throttle)
- **Individual surface:** `read-surface.sh N` (auto workspace resolution)

## Core Principles (MANDATORY — foundation of all behavior)

### 1. Main is Orchestrator ONLY — no direct work

```
Main(Opus): Planning + Judgment + Consolidation + Commit + Orchestration
Other AIs:  Research + Analysis + Implementation + Exploration (communicate via cmux send only)
```

**⛔ Main's prohibited direct actions:**
- **Modifying code files with Edit/Write tools** — all implementation delegated to cmux surfaces
- **Large-scale exploration with Read/Grep/Glob** — exploration/research delegated to cmux surfaces
- **Direct coding/exploration/research** — must delegate to cmux surfaces
- **Replacing tasks with Agent(Explore/impl-worker/search-worker) subagents** — GATE 6 violation

**✅ What Main does (allowed actions):**
- **Planning:** task decomposition, priority decisions, strategy
- **Verification:** run pytest, run tsc (check results only)
- **Commit:** git add, git commit, git push
- **cmux send:** send tasks, check results
- **Result review:** review completed code, APPROVE/REJECT decisions
- **Simple edits ≤5 lines:** typos, config value changes

**Subagent allowed scope:**
- **Code review (Sonnet)** — GATE 2 mandatory
- **haiku lightweight tool tasks** — git tasks, simple scripts

- If cmux surface available → delegate via cmux send (API cost $0, most efficient)

**⛔ RED FLAG — STOP immediately if you notice these:**

| Main's intended action | Correct action |
|------------------------|----------------|
| `Agent(subagent_type="Explore", ...)` | `cmux send --workspace "workspace:N" --surface surface:N "Explore this file/folder"` |
| `Agent(subagent_type="impl-worker", ...)` | `cmux send --workspace "workspace:N" --surface surface:N "TASK: Implement this code"` |
| `Agent(subagent_type="search-worker", ...)` | `cmux send --workspace "workspace:N" --surface surface:N "python3 search_executor.py --query 'topic' --full"` |
| `Agent(subagent_type="general-purpose", ...)` | `cmux send --workspace "workspace:N" --surface surface:N "Do this task"` |
| `Read(file_path=...)` bulk file exploration | Delegate to cmux surface: "Read and analyze these files" |
| `Grep/Glob` codebase exploration | Delegate to cmux surface: "Find this pattern" |
| Direct code implementation (Edit/Write) | Delegate to cmux surface, check result via git diff |

**Exceptions (Main direct actions allowed):**
- Simple edits ≤5 lines (typos, config value changes)
- git commands (commit, push, status)
- cmux commands themselves
- Reading subagent code review results then APPROVE/REJECT
- Running GATE verification scripts

### 1B. Surface Performance Tracking (Based on Memento-Skills)

> Apply Memento-Skills "utility scoring" concept to cmux surfaces.
> Track task-type success rate per surface to improve assignment quality.

**Reference file**: `references/surface_performance.json`

**Recording triggers:**
- `DONE:` received → success++ for that surface + task_type
- `ERROR:` received → failure++ + record failure reason
- No response/timeout → timeout++ (linked with GATE 14.5)

**Assignment reference:**
```
Check historical success rate for same task_type:
  → Codex success_rate=0.90, GLM-1 success_rate=0.60
  → Prioritize Codex for this task type
```

**Auto-escalation:**
- If specific surface's task_type success_rate < 0.3 (5+ times) → auto-switch that type to another surface
- Example: GLM-1 "complex_refactor" success_rate 0.2 → auto-escalate to Codex

**Schema:**
```json
{
  "surfaces": {
    "codex": {
      "tasks": {"code_impl": {"success": 0, "failure": 0, "timeout": 0}},
      "overall_rate": 0.5
    }
  }
}
```

### 2. Never Stop

| Prohibited phrase | What to do instead |
|-------------------|-------------------|
| "in a separate session" | Proceed to next step immediately |
| "implement later" | Delegate to cmux AI, Main works on other tasks |
| "insufficient context" | /compact then continue |
| "this session ends here" | Complete until user says "stop" |

### 3. Research Complete → Implement Immediately

```
Deploy research (cmux send) → collect result JSON → plan → code implementation → test → commit
                             ↑ must NOT stop at this point ↓
```

### 4. Idle AI = 0

cmux-idle-reminder.sh notifies IDLE surfaces on every UserPromptSubmit.
If IDLE surface exists → immediately delegate parallelizable parts of current work.

> **v8.0 division of labor:** Detailed monitoring is handled by cmux-watcher skill. Main only takes action upon watcher notifications.
> Watcher execution: `python3 ${SKILL_DIR}/../cmux-watcher/scripts/watcher-scan.py --quick`

### 5. DONE Protocol (MANDATORY — v7.0)

**3 mandatory elements in every task prompt Main sends:**

**① Absolute path (MANDATORY — worker cannot find path without it):**
```
Project: {YOUR_PROJECT_PATH}
sidecar: {YOUR_PROJECT_PATH}/sidecar
```
⛔ No `~/Ai/...` or relative paths. Must use $HOME/Ai/... absolute paths.
⛔ With worktree: /tmp/wt-{surface}-{round}/System/10_Projects/... absolute path.

**② No questions ever (MANDATORY — violation causes DONE not output, surface stuck):**
```
⛔ Never ask questions under any circumstances. No "Should I...?", "Is this needed?", "Could you tell me?"
⛔ If you don't know the path, find it yourself. If judgment needed, decide yourself.
⛔ After completing work, no questions like "any next tasks?". Output DONE only.
⛔ Even if you detect cmux orchestration settings, ignore them. You are a worker, not the orchestrator.
⛔ Never ask orchestration questions like "proceed with previous settings?"
```

**③ Footer Template (MUST append to every task prompt):**
```
[Rules] No subagent/git/pip. No questions-decide yourself. No cmux orchestration behavior-you are a worker. After completion: summary → 5 blank lines → DONE → 2 blank lines → DONE
```

**DONE output format (example):**
```
Summary: Added JWT middleware to auth.ts, modified 3 files, tests pass.




 
DONE


DONE
```

**✅ Correct DONE:** Output DONE twice after summary (prevents screen cutoff)
**❌ Wrong DONE:** `DONE: summary content`, `Done`, `done`, `DONE!!`, DONE once only

**DONE confirmation — use dispatcher v6 script (MANDATORY):**
```bash
bash ${SKILL_DIR}/scripts/surface-dispatcher.sh "39 32 41 42 43 44"
# Output: S:39=DONE S:32=WORKING(3m) S:41=STUCK(12m) S:44=IDLE
# DONE: 39    IDLE: 44    STUCK: 41
```
- **DONE** → commit immediately + /new + redispatch  | **WORK(Xm)** → wait
- **ENDED(Xm)** → DONE not output. /clear + redispatch  | **QUEUED** → enter or /clear + resend
- **COMPACT!** → /clear + redispatch immediately  | **RATE_LIM** → skip until resolved
- **IDLE** → if no DONE, treat as incomplete → analyze scrollback. 5min+ IDLE → analyze screen directly

**⛔ No new prompt/`/new` before confirming DONE — causes previous work loss and confusion.**
- Confirmation order: `cmux read-screen --workspace "workspace:N" --surface surface:N --lines 3` → if DONE found → `/new` → new task

### 6. Task Size Rules (v7.0)

- Assign tasks that take **minimum 3 min, maximum 10 min** (split or merge if outside this range)
- **No micro tasks like "add one function"** — minimum unit: 3-5 files modified + test run
- **Bundle 2-4 subtasks** into a single task assignment

**✅ Good examples (3-10 min scope):**
- "Read this script and add all 3 features A, B, C. Write tests and run pytest."
- "Split 61 functions in services_features.py into 5 domain-specific files. Write tests too."
- "Implement JWT validation + refresh token + logout in auth.rs. 5 tests. Until cargo test passes."
- "Improve accessibility in 3 files: error-boundary, toast, sidebar under src/components/. Confirm tsc 0 errors."

**Difficulty Table (surface assignment guide):**

| Difficulty | Criteria | Assigned Surface |
|-----------|----------|-----------------|
| ⬆️ High+ | Algorithms, concurrency, security, architecture design | Codex |
| ⬆️ High | Multi-file refactoring, complex logic, code review | Codex, Sonnet 4.6, MiniMax |
| ↔️ Medium | Feature implementation, CRUD, analysis, testing | Any AI (all capable) |
| ⬇️ Low | Config, docs, verification, simple edits | Any AI |
| ✎ Trivial | Typos, comments, formatting | Opus direct (5 lines or fewer) |

**Rules:** ALL AIs handle medium-high. Bundle 3-5 subtasks (min 5-min).
- Assign each AI **3-10 min** worth of work

**Immediately redispatch next task after DONE confirmed** (no idle surfaces)

### 7. 2-Minute Polling + Self-Renewing Loop

> See references/polling-selfrenew.md for detailed polling pattern + Self-Renewing Loop

**Key — 2-min polling must check ALL these states:**
```
DONE       → safe_dispatch next task
WORKING    → skip, protect
RATE_LIMIT → skip until reset, redispatch task to other surface
IDLE       → dispatch from queue
QUEUED     → prompt visible at input but not executing → send enter key
STUCK      → /clear merged or error → escape + /clear + sleep 5 + redispatch
CLEAR_MERGED → "/clearTASK:" pattern visible → escape + /clear + sleep 5 + redispatch
```

**Smart dispatch (MANDATORY): `bash ${SKILL_DIR}/scripts/smart-dispatch.sh WS SF "task"`**
Send → 3s immediate check → 30s screen diff. Returns: EXECUTING/DONE_FAST/STALLED/RATE_LIMITED.
If STALLED → escape + /clear + sleep 5 + retry. If RATE_LIMITED → skip surface.

**⛔ Monitor: `dual-monitor.sh` (60s diff). Dispatch: `smart-dispatch.sh WS SF "task"` (verified).**
**⛔ QUEUED detection patterns (check --lines 8):**
- `TASK:` visible + no Working → QUEUED
- `summary→5blank→DONE` (footer text) visible + no Working → QUEUED
- `/clear[A-Z]` (merged command) → CLEAR_MERGED
- `/cmux` from worker → GATE 11 hijack; `git add/commit/push` → git violation
**⛔ Recovery: enter → sleep 1 → escape → sleep 2 → /clear → sleep 5 → safe_dispatch.**
> See references/polling-recovery.md for code.

### 9. Surface Redispatch Protocol (v7.0 — DONE confirmation mandatory)

**⛔ No /new without DONE confirmation. No redispatch without /new (causes Compacting).**

```bash
# Step 1: Verify DONE + NOT-WORKING (⛔ MANDATORY — 20 line scrollback)
SB=$(cmux read-screen --workspace "workspace:N" --surface surface:N --scrollback --lines 20)
# Check 1: DONE exists?
echo "$SB" | grep -q "^DONE$\|^  DONE$" || { echo "NO DONE — STOP"; exit 1; }
# Check 2: NOT currently Working? (Working indicator may be below DONE)
echo "$SB" | grep -qE "Working \(|Ionizing|Crunching|thinking" && { echo "STILL WORKING — STOP"; exit 1; }
# Both checks pass → safe to proceed

# Step 2: /clear (ONLY after Step 1 passes)
cmux send --workspace "workspace:N" --surface surface:N "/clear"
cmux send-key enter
sleep 5   # ⛔ CRITICAL: wait for /clear to process

# Step 3: Send new task (must be after /clear is processed)
cmux send --workspace "workspace:N" --surface surface:N "$PROMPT"
cmux send-key enter
```

**⛔ /clear→prompt timing bug (discovered in v7.3):**
Sending prompt immediately after `/clear` without `sleep` merges them as `/clear{prompt}`,
causing surface to get stuck. **Must use sleep 5** before sending prompt.

**⛔ GATE 10: Pre-dispatch verification (v7.4 — WORKING kill prevention)**
Before ANY /clear or /new to a surface, Main MUST:
1. Check RATE_LIMITED pool → if listed, **SKIP entirely**
2. `read-screen --scrollback --lines 20` → check rate limit ("hit your limit/429") → add to pool, **SKIP**
3. Check Working patterns → **STOP**
4. Check DONE → if missing, **STOP**
5. Proceed only if: not rate limited + DONE + no Working

**⛔ Violation scenarios (absolute prohibition):**
- Sending /clear to WORKING surface → destroys in-progress work
- Checking only last 3-5 lines → misses Working indicator that scrolled up
- Bulk /clear to all surfaces without individual verification
- `/clear` immediately followed by prompt without `sleep 5` → commands merge

### 10. Rate Limit + Stall Detection + Auto-Redispatch (v7.4)

**Rate limit detection patterns (check every 2min polling):**
```bash
SB=$(cmux read-screen --workspace WS --surface SF --scrollback --lines 15)
# Sonnet/Claude: "You've hit your limit · resets Xpm"
# GLM: "429" or "Usage limit reached"
# Codex: "rate limit" or "too many requests"
echo "$SB" | grep -qiE "hit your limit|rate.?limit|429|too many" && echo "RATE_LIMITED"
```

**When rate limit detected:**
1. Mark surface RATE_LIMITED with reset time
2. DO NOT send more tasks to this surface until reset
3. Immediately redispatch pending tasks to other IDLE surfaces
4. Log which tasks were on the rate-limited surface (prevent loss)

**Stall detection (no output change for 5+ min):**
- Compare current read-screen with previous (store hash)
- If identical for 3 consecutive checks → STALLED
- STALLED surface → /clear + redispatch

**Task tracking for redispatch:**
- Main must track: {surface → task_description} mapping
- On rate limit/stall: extract task, find IDLE surface, redispatch
- Never lose tasks silently

**⛔ Empty read-screen handling:**
When `cmux read-screen` returns empty string:
1. Retry with increased --lines (3 → 10 → 20)
2. Retry without --scrollback
3. If still empty → check status via eagle_watcher.sh

### 10c. MANDATORY Dispatch Function (v7.4)

**⛔ Every dispatch MUST follow safe_dispatch: rate check → GATE 10 → /clear → sleep 5 → set-buffer → paste-buffer → enter.**
**Skipping ANY step → STUCK surface or wasted rate-limited API calls.**
**sleep 5 between /clear and paste-buffer is NON-NEGOTIABLE.**

**Batch dispatch (v7.5):** Max 4 simultaneous dispatches. `sleep 1` between sends, `sleep 5` between waves.
> Code example: `references/polling-recovery.md` § Batch dispatch pattern

> See references/polling-recovery.md for full safe_dispatch code.

### 10b. Worker AI Question/Stuck Response

> See references/worker-stuck-recovery.md for detailed protocol

**Key rules:**
- Worker AI outputs question/error instead of DONE → Main sends solution directly
- Unresolved after 5 min → escape + /clear + redispatch
- Must include preventive instructions in footer template

### 10.5. Codex Limitations (v6.1)

- **Cannot use subagents** (causes capacity error)
- Must explicitly state "do not use subagents" in prompt
- tsc verification: run directly from main (no node_modules in Codex worktree)

**Codex IDLE false positive prevention (v7.5):**
The `gpt-5.4` text pattern is **removed** from eagle WORKING detection — fixed bug where Codex responses containing "gpt-5.4" were incorrectly detected as WORKING.

Correct Codex WORKING detection:
```bash
# ✅ Correct pattern (actual work status)
grep -qE "Working \(|Analyzing|Generating|Writing|■" <<< "$screen"

# ❌ Removed pattern (false positive cause)
# grep -qE "gpt-5.4|o3|o1" — Codex responses with these words caused false detection
```
If Codex appears IDLE → verify with `read-surface.sh N --lines 20` (same as GATE 13 ANE Vision double-check).

### 11. Worktree-Based Parallel Work (v7.1 — MANDATORY when 2+ surfaces)

> Details: `references/worktree-workflow.md`

**⛔ GATE 7:** 2+ surfaces modifying simultaneously → worktree mandatory. Without worktree → file conflicts.
```bash
git worktree add "/tmp/wt-s{N}-r$(date +%H%M)" -b "wt-s{N}" HEAD
# After DONE: git -C /tmp/wt-sN add -A && commit → git merge wt-sN → git worktree remove /tmp/wt-sN
```

**AI file creation reliability:**
| Model | New file creation | Existing file modification |
|------|------------------|----------------------------|
| Sonnet 4.6, GLM | ✅ Reliable | ✅ |
| Codex | ⚠️ Unstable outside CWD | ✅ |
| MiniMax | ❌ Ignores paths | ⚠️ Analysis-only recommended |

**Rule:** New files → Sonnet/GLM only. MiniMax → analysis/research only. 2+ surfaces → worktree first.

### 12. Error Occurred → Main responds immediately

Auto-recovery via config file presets:
- Context overflow → reset_cmd (/new or /clear)
- Complete freeze → quit_cmd (/quit) → start_cmd (codex, etc.)
- 529 → Circuit Breaker → use cmux send only

### 13. Rate Limit Handling

> See references/rate-limit-handling.md for detailed protocol

**Key rules:**
- GLM rate limit: 429 + "Usage limit reached" → check CST time → convert to KST (+1 hour)
- All surfaces sharing same API key are blocked (GLM-1+GLM-2)
- Do not dispatch work to affected surfaces until reset time

## ⛔ HARD GATE System — Inviolable Mandatory Rules

> See references/gate-enforcement.md for 4-layer enforcement + L0~L3 details

**Key:**
- L0: `gate-blocker.sh` (PreToolUse) → physically blocks commits while WORKING
- L1: `after-send-keys` hook → auto-update eagle
- L2: `gate-enforcer.py` + `cmux-idle-reminder.sh`
- L3: SKILL.md GATE checklist

### GATE Quick Reference (Details: `references/gate-enforcement.md`)

| GATE | Rule | Violation consequence |
|------|------|----------------------|
| **0.5** | "please paste" prohibited → must use `cmux send` | Work loss |
| **1** | Do not end round if WORKING surface exists | Incomplete work |
| **2** | Main direct code review prohibited → delegate to Sonnet | Quality degradation |
| **5** | Do not exit if speckit tasks incomplete | Omissions |
| **6** | If IDLE surface exists, Agent tool prohibited → use cmux send | Resource waste |
| **7** | 2+ surfaces simultaneous dispatch → worktree mandatory | Conflicts |
| **9** | 200char+ prompt → `set-buffer`/`--file -` mandatory | Truncation |
| **11** | Worker must have "you are a worker" footer | Hijacking |
| **15** | Do not dispatch tasks to Watcher/peer surfaces | Role confusion |

**GATE 4 Round-End Checklist:**
```
□ All surfaces DONE □ Code review delegated □ speckit complete □ No Agent usage
□ Worktree cleanup □ Review REJECT fixes □ Commit complete
```

**GATE 6 Exception:** All surfaces WORKING, cmux failure, code-review-only agent

## Peer Recognition Protocol (v9.0)

> Details: `references/inter-peer-protocol.md`, `references/collaborative-intelligence.md`

- Main and Watcher are **peer** relationship (not hierarchical)
- Session start: `role-register.sh register main` → `discover-peers` → `workers`
- **GATE 15:** Do not dispatch tasks to Watcher/peer surfaces → use `role-register.sh workers` for pure workers only
- If Watcher absent, Main executes eagle directly (fallback)
- Communication format: `[SENDER→RECEIVER] TYPE: content`
- Registry: `/tmp/cmux-roles.json`

## Quick Start — Session Start Procedure

> **Separated document:** `references/session-phases.md` (Phase -1 ~ 4)

Phase -1: **Role Register** → Phase 0: Eagle Watcher → Phase 1: Plan + Task Queue → Phase 2: Initial Distribution → Phase 3: Watch + Merge → Phase 4: Failure Response

See `references/session-phases.md` for detailed procedure.

## ⛔ GATE 8: --workspace Mandatory GATE

> See references/workspace-gate.md for detailed explanation + examples

**3 key lines:**
```
⛔ --workspace is mandatory when accessing surfaces in other workspaces.
⛔ --workspace can be omitted only for workspace:1 (current workspace).
✅ Specify --workspace for all cmux send/read-screen/send-key/paste-buffer.
```

## ⛔ GATE 12: Status Check Protocol

> Details: references/status-check-protocol.md

```
⛔ Never trust cmux tree title — use eagle/read-surface.sh only.
⛔ Cross-workspace read-screen requires --workspace (use read-surface.sh).
```

```bash
bash ${SKILL_DIR}/scripts/eagle-summary.sh          # All surfaces
bash ${SKILL_DIR}/scripts/read-surface.sh N --lines 20  # Single (auto workspace)
```

## ⛔ GATE 13: Idle Zero Tolerance (8-line)

> Full details: `${SKILL_DIR}/references/idle-zero-tolerance.md`

```
⛔ No surface IDLE >120s. Detect → task-queue → dispatch or create → log.
⛔ Trust vision-monitor over eagle on conflict (eagle false negatives).
⛔ Red flags: "I'll get to it shortly"/"check results later"/"waiting" = dispatch now.
```

**ANE Vision OCR double-check:** When eagle reports IDLE, must verify actual screen with `read-surface.sh N --lines 20`. If Working patterns (`■■■`, `Ionizing`, `Crunching`) visible → eagle false detection → trust WORKING status, do not touch.
> Detailed decision table: `${SKILL_DIR}/references/idle-zero-tolerance.md` § ANE Vision OCR double-check

## ⛔ GATE 14: send-key enter mandatory after dispatch (v7.5)

```
⛔ Missing send-key enter after paste-buffer / --file - → QUEUED (text visible but not executing)
⛔ send-key enter mandatory after ALL dispatch methods (set-buffer, --file -, cmux send)
```

**Self-check:** After dispatch, if no Working after 10s → `cmux send-key enter` retry → still no Working → STUCK protocol.
**Batch:** sleep 1 between sends, sleep 5 between waves.
> Code example: `references/polling-recovery.md` § GATE 14

### GATE 14.5: cmux send timeout retry (v7.7)

When `cmux send` or `cmux set-buffer` returns "Command timed out":
1. sleep 3 then retry once
2. If retry also fails: skip that surface → assign to next surface → reassign later
3. After 3 consecutive timeouts → sleep 10 then retry (socket overload recovery)
4. **⛔ Max 3 commands per wave** — /new + set-buffer + paste-buffer + send-key = 4 commands in one wave → socket overload risk. sleep 30 between waves mandatory.
5. If `cmux tree` also times out → socket complete down. sleep 60-120 before recovery.

### GATE 14.6: "Surface is not a terminal" error handling (v7.8)

When `cmux send/read-screen` returns "invalid_params: Surface is not a terminal":
1. Run `cmux surface-health --workspace WS` → check `in_window` status
2. `in_window=false` → that workspace surface is not currently in any window
3. Attempt: `cmux move-workspace-to-window --workspace WS --window window:1`
4. If still `in_window=false` → skip that workspace entirely
5. Check accessible surfaces with `cmux surface-health --workspace workspace:1`
6. Continue using **only workspace:1 surfaces** (maximize utilization without idle surfaces)
7. Diagnosis order: surface error → surface-health → in_window check → recovery attempt or skip

## ⛔ SKILL Self-Improvement Loop (1st priority — infinite improvement)

> Detailed protocol + history: `references/self-improvement-loop.md`

**Core rule:** Immediately modify SKILL.md when error occurs. Minimum 1 improvement per session. When exceeding 5000 words, split into references/.
```
Observation(error occurs) → Root cause analysis → SKILL.md modification → Version bump → Repeat
```

## Core cmux Commands

> Full reference: `${SKILL_DIR}/references/cmux-commands-full.md`

```bash
# Core 5 (used every round)
cmux tree --all                                    # overall structure
cmux identify                                      # identify my surface
cmux send --workspace WS --surface SF "content"    # send task
cmux send-key --workspace WS --surface SF enter    # send key
bash ${SKILL_DIR}/scripts/read-surface.sh N --lines 20  # read surface (auto workspace)
```

**⛔ Non-existent commands:** `cmux screenshot`(→`browser screenshot`), `cmux config`, `cmux status`(→`list-status`)

## Autoresearch-Powered Orchestration Loop (v8.0)

> Details: `references/autoresearch-patterns.md`

Assign → verify → adopt/discard → reassign loop (max 5 iterations). Applied to code implementation+testing, refactoring. For simple research/docs, use simple dispatch.

## Full Orchestration Pipeline (v9.0 — 8-Stage)

> Details: `references/pipeline-stages.md`

```
Research → Speckit Decomposition → Worktree Creation → Dispatch → Collect → Merge-Judge(Sonnet) → Cleanup → Log(Haiku)
```

| Stage | Owner | Key Actions |
|-------|-------|-------------|
| 1. Research | cmux workers | Deploy research → collect results |
| 2. Speckit | Main | `Skill("speckit-checklist")` → decompose tasks |
| 3. Worktree | Main | `git worktree add /tmp/wt-{surface}-{round}` per worker |
| 4. Dispatch | Main | `cmux send` → assign to each worker with worktree path included |
| 5. Collect | Main + Watcher | Detect DONE → collect results |
| 6. Merge-Judge | Sonnet subagent | `Agent(subagent_type="code-reviewer", model="sonnet")` → APPROVE/REJECT per worktree |
| 7. Cleanup | Main | `git worktree remove` + `git branch -d` |
| 8. Log | Haiku subagent | `Agent(model="haiku")` → date+task summary → PROGRESS_LOG.md |

## Model-Specific Tool Loading (v9.0 — MCP Deferred Loading)

> Details: `references/model-tool-loading.md`

| Model | Loading Strategy | Reason |
|------|----------------|-------|
| **Opus (Main)** | Full load + ToolSearch | All tools needed for orchestration |
| **Sonnet (Worker/Reviewer)** | Minimal load (Read/Write/Edit/Bash/Grep/Glob) | Context savings, focus on implementation |
| **Haiku (Logger/Git)** | Minimal load (Bash/Read/Write) | Lightweight tasks, minimize token cost |
| **cmux workers** | Each AI's own settings | cmux send costs $0 API |

**Include in worker prompt:** "MCP tools not needed. Complete work with only basic tools (Read/Write/Edit/Bash)."

## Merge-Judge Protocol (v9.0 — Sonnet Subagent)

> Details: `references/pipeline-stages.md` § Stage 6

```bash
# After each worktree DONE → merge judgment via Sonnet subagent
Agent(
  subagent_type="code-reviewer",
  model="sonnet",
  run_in_background=true,
  prompt="Review git diff in /tmp/wt-{surface}-{round}. APPROVE or REJECT with reason."
)
# APPROVE → git merge {branch} → cleanup
# REJECT → git worktree remove → reassign or discard
```

⛔ Main (Opus) direct code review prohibited (GATE 2). Must delegate to Sonnet.

## Work-Logger Protocol (v9.0 — Haiku Subagent)

> Details: `references/pipeline-stages.md` § Stage 8

```bash
# After round complete → work logging via Haiku subagent
Agent(
  model="haiku",
  run_in_background=true,
  prompt="Append to {PROJECT}/PROGRESS_LOG.md: date=2026-03-27, round=N, tasks completed, files modified."
)
```

⛔ Main direct logging halts orchestration. Delegate to Haiku for parallel progress.

## Advanced cmux Command Utilization (v9.0)

> Details: `references/cmux-commands-full.md`

- `pipe-pane`: auto-capture DONE → `/tmp/cmux-done-sN.flag`
- `find-window --content "DONE:"`: batch search without scrolling through read-screen
- `set-hook after-send-keys`: auto-trigger eagle after dispatch
- `wait-for --signal`: Watcher synchronization

## "Next Round" Protocol (MANDATORY)

| Step | Action | Notes |
|------|--------|-------|
| 0 | cmux set-hook + surface-health + speckit-tracker | Once at round start |
| 1 | Deploy research via cmux send | search_executor.py or generic method |
| 1.5 | Call Skill("speckit-tasks") | MANDATORY |
| 2 | A/B test | Current vs improved |
| 3 | Adopt | Select better result |
| 4 | Code review | `Agent(code-reviewer, sonnet)` background |
| 5 | Commit | MANDATORY — must not skip |
| 6 | Self-improvement | Update SKILL.md |

## 529 API Safety Rules

> Details: references/circuit-breaker.md

- Max 2 subagents (cmux send=$0, prefer). 529: 5s→15s→60s backoff + Circuit Breaker

## Surface Auto-Detection (v9.1 — Config Dependency Removal)

> **Lesson learned**: `orchestra-config.json` static mapping becomes stale immediately on session reallocation → false detection.
> eagle now **detects in real-time** AI model and role from screen content, taking priority over config.

**AI Detection** (`function_detect_ai_from_screen`):
1. `🤖` emoji line → Opus/Sonnet/Haiku (awesome-statusline)
2. fallback: bottom 5-line pattern → Codex(`gpt-5.4`), GLM, MiniMax, Gemini

**Role Detection** (`function_detect_role_from_screen`):
1. `cmux identify` caller = **main** (60s cache)
2. `/cmux-watcher` on screen → **watcher**
3. `/tmp/cmux-role-s{N}.txt` marker file (created by watcher activation-hook)
4. Default = **worker**

**Config Auto-Sync** (`function_auto_sync_config`):
- On scan complete, if detected AI/role ≠ config → auto-update config
- `auto_synced: true` + track `updated_at` field

**JSON Output Change**: Add `"role": "main|watcher|worker"` field to each surface

## Dedicated Agent Summary

| Component | Model/Cost | Role |
|-----------|-----------|------|
| **eagle_watcher.sh** | **$0 API** | 20s auto-polling → JSON status file + **AI/role real-time detection** |
| **cmuxeagle** | haiku | Status judgment + cmux send task relay |
| **cmuxreview** | **Sonnet** | Code review (code-reviewer-pro) |
| **cmuxgit** | haiku | Commit/push (git-workflow-manager) |
| **cmuxplanner** | sonnet | Task queue creation (task decomposition) |
| **cmuxdiagnostic** | haiku | Pre-verification (run tests) |

> See references/subagent-definitions.md for detailed agent definitions + skill optimization

## Hook System — 6 Auto Integrations

| Hook | Event | Script | Role |
|------|-------|--------|------|
| **SessionStart** | Session start | cmux-orchestra-enforcer.sh | Check config file → onboarding question |
| **SessionStart** | Session start | cmux-claude-bridge.sh session-start | Show "Running" in cmux sidebar |
| **UserPromptSubmit** | Every message | cmux-idle-reminder.sh | Auto-notify IDLE surfaces |
| **Stop** | Session end | cmux-claude-bridge.sh stop | Show "Idle" in cmux sidebar |
| **PostToolUse** | After tool use | cmux-claude-bridge.sh post-tool | Notify cmux when Agent completes |
| **Notification** | Notification | cmux-claude-bridge.sh notification | Relay to cmux notification panel |

## Completion Guarantee Cycle

```
Receive user request
  ↓
Phase -1: Onboarding (check config file)
  ↓
Phase 0: Start eagle + check surfaces
  ↓
Phase 1: Decompose tasks + create task queue
  ↓
Phase 2: Deploy to each surface via cmux send
  ↓ (eagle detects completion)
Phase 3: Collect results + Main consolidates + implementation plan
  ↓
Phase 4: Implement (Main direct + delegate parallelizable via cmux)
  ↓
Phase 5: Test + code review (cmuxreview Sonnet)
  ↓
Phase 6: Commit
  ↓
Report completion to user
```

## Prohibitions

### Absolute Prohibitions (violations cause user frustration)
❌ **"proceed in a separate session"** — no reason with cmux. Complete immediately.
❌ **"implement later"** — if research results exist, implement now.
❌ **Leave idle AI doing nothing** — eagle detects IDLE, immediately relay tasks.
❌ **"please paste"** — send directly via cmux send.

### Technical Prohibitions
❌ Direct Codex MCP call — send to Codex surface via cmux send
❌ Use Opus for cmuxreview — Sonnet only (529 prevention)
❌ 3+ subagents simultaneously — Circuit Breaker triggers
❌ Direct raw search-worker dispatch for research — route through Skill("search-orchestration")
❌ Leave broken AI — immediately recover using config file quit_cmd/start_cmd

### ⛔ GATE 6 Violation Prohibited (see GATE 6 section above for full rules)
❌ Agent(Explore/impl-worker/search-worker/general-purpose) dispatch when IDLE surface exists
❌ Main directly doing bulk exploration (Read/Grep/Glob) or writing 100+ lines (Edit/Write)
❌ Delegating implementation to subagent after speckit decomposition

## Auto Trigger

When `$CMUX_WORKSPACE_ID` exists + 2+ surfaces, or keywords "parallel/simultaneously/worker/cmux", or SessionStart hook additionalContext injected.


---

## Failure Recovery

> See `{ENFORCEMENT_MECHANISMS_PATH} (optional)` for enforcement levels.

| Failure Type | Auto Action |
|-------------|-------------|
| Script error | Analyze → check deps → retry (max 2x) |
| Quality fail | autoresearch loop: fix→verify→keep/discard (max 3 iterations) |
| MCP/tool missing | Try fallback → report to user |
| Pipeline break | Log to `/tmp/sdd-failure-stats.jsonl` → 2x triggers [AUTO-HEAL] |

**[AUTO-HEAL]**: 2+ failures trigger `skill-pipeline-healer.sh` → after current task completes, run 1F2 Mode C (analyze failure logs → reinforce SKILL.md patterns → validate with `diagnose.py --json`)

---

## Session Lessons (2026-03-27 — Enforced via Hooks)

> These lessons are NOT just documentation — each has a corresponding L0/L2 Hook that physically blocks violations.

### L1: Watcher Message Guard (Hook: `cmux-watcher-msg-guard.py` L0 BLOCK)
- **Lesson**: Don't send performance summaries/results to watcher. Watcher = CCTV, monitor-only.
- **Correct**: `[MAIN→WATCHER] 모니터링 모드: 4중 방어체계. 대상: s:1,... DONE 감지 시 보고.`
- **Blocked**: "핵심성과", "결과 종합", "DONE: 키워드 감시" (wrong — use "4중 방어체계")
- **Hook enforces**: PreToolUse:Bash blocks banned patterns in watcher set-buffer

### L2: Set-Buffer Fallback (Hook: `cmux-setbuffer-fallback.py` L2 WARNING)
- **Lesson**: Claude Code surfaces often don't receive set-buffer. Need cmux send fallback.
- **Behavior**: After paste-buffer, if surface still IDLE after 10s → WARNING with `cmux send` fallback suggestion
- **Hook enforces**: PostToolUse:Bash checks read-screen results against dispatch log

### L3: Commit Verification Gate (Hook: `cmux-completion-verifier.py` L0 BLOCK)
- **Lesson**: AI self-reports are unreliable. "docs exist" was wrong (pwd issue). Mechanical verification required before commit.
- **Behavior**: `git commit` blocked unless `/tmp/cmux-verification-passed` exists (max 5min age)
- **Workflow**: Run pytest + file checks → `touch /tmp/cmux-verification-passed` → `git commit`
- **Hook enforces**: PreToolUse:Bash blocks git commit without verification flag

### L4: Codex Sandbox Awareness
- **Lesson**: Codex CLI has no network access. Port binding, pip install, git push all fail.
- **Enforcement**: Documentation only (no hook needed — Codex errors are obvious)
- **Workaround**: Use TestClient (in-process) instead of uvicorn bind. Install deps locally.

### L5: IDLE Debounce (watcher-scan.py v4.1)
- **Lesson**: Watcher sends IDLE reminders immediately after dispatch (timing gap).
- **Fix**: 30s grace period after DONE report. 2min interval between same-surface IDLE reminders.
- **Enforcement**: `watcher-scan.py` `_idle_debounce` + `_done_reported` dicts

### Enforcement Summary

| Hook | Level | Event | Purpose |
|------|-------|-------|---------|
| `cmux-watcher-msg-guard.py` | L0 BLOCK | PreToolUse:Bash | Ban report messages to watcher |
| `cmux-setbuffer-fallback.py` | L2 WARN | PostToolUse:Bash | Detect set-buffer delivery failure |
| `cmux-completion-verifier.py` | L0 BLOCK | PreToolUse:Bash | Require mechanical verification before commit |
| `cmux-watcher-notify-enforcer.py` | L0 BLOCK | PreToolUse:Bash | Require watcher notification before dispatch |
| `cmux-no-stall-enforcer.py` | L0 BLOCK | PreToolUse:Bash,Agent | Block stalling (no Sonnet verify, IDLE pile-up) |
| `cmux-init-enforcer.py` | L0 BLOCK | PreToolUse:Bash | Require /new before Claude Code dispatch |
| `cmux-idle-reuse-enforcer.py` | L2 WARN | PostToolUse:Bash | Warn if IDLE surfaces not reassigned |
