#!/usr/bin/env python3
"""cmux-watcher-notify-enforcer.py — PreToolUse:Bash Hook (L0 BLOCK)

워커 surface에 작업 배정 후 와쳐에 알리지 않으면 다음 Bash 명령을 BLOCK.

동작:
1. cmux set-buffer --surface (워커) 감지 → pending에 surface 기록
2. cmux set-buffer --surface surface:29 (와쳐) 감지 → pending 해소
3. pending이 남은 상태에서 다른 Bash 실행 시 → BLOCK (approve가 아닌 block)
4. 와쳐에 알림 보내는 명령만 통과 허용
"""
import json
import os
import re
import sys
import time

PENDING_FILE = "/tmp/cmux-dispatch-pending.json"
WATCHER_SURFACE = "surface:29"

def load_pending():
    if os.path.exists(PENDING_FILE):
        try:
            with open(PENDING_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"surfaces": [], "timestamp": 0}

def save_pending(data):
    with open(PENDING_FILE, "w") as f:
        json.dump(data, f)

def main():
    inp = json.loads(sys.stdin.read())
    tool_name = inp.get("tool_name", "")
    tool_input = inp.get("tool_input", {})
    command = tool_input.get("command", "")

    if tool_name != "Bash":
        print(json.dumps({"decision": "approve"}))
        return

    # cmux set-buffer 감지
    if "cmux set-buffer" in command and "--surface" in command:
        pending = load_pending()

        # 와쳐에 보내는 건 → pending 전부 해소
        if WATCHER_SURFACE in command:
            pending["surfaces"] = []
            pending["timestamp"] = 0
            save_pending(pending)
            print(json.dumps({"decision": "approve"}))
            return

        # 워커에 보내는 건 → pending 추가
        m = re.search(r'surface:(\d+)', command)
        if m:
            sid = f"surface:{m.group(1)}"
            if sid not in pending["surfaces"]:
                pending["surfaces"].append(sid)
            pending["timestamp"] = time.time()
            save_pending(pending)

        print(json.dumps({"decision": "approve"}))
        return

    # cmux paste-buffer, send-key, rename-tab, display-message → 항상 허용
    if re.search(r'cmux (paste-buffer|send-key|rename-tab|display-message|read-screen|capture-pane|tree|identify)', command):
        print(json.dumps({"decision": "approve"}))
        return

    # sleep → 허용
    if command.strip().startswith("sleep"):
        print(json.dumps({"decision": "approve"}))
        return

    # pending 확인 — 와쳐 미알림 상태에서 다른 작업 시도 시 BLOCK
    pending = load_pending()
    if pending["surfaces"] and (time.time() - pending["timestamp"]) > 3:
        surfaces_str = ", ".join(pending["surfaces"])
        print(json.dumps({
            "decision": "block",
            "reason": f"[WATCHER-BLOCK] ⛔ {surfaces_str}에 작업 배정했지만 와쳐(surface:29)에 알림을 보내지 않았습니다. 먼저 cmux set-buffer --surface surface:29 로 와쳐에 모니터링 요청을 보내세요."
        }))
        return

    print(json.dumps({"decision": "approve"}))

if __name__ == "__main__":
    main()
