#!/bin/bash
# cmux-dispatch-notify.sh — cmux 디스패치 시 와쳐 자동 알림
# PostToolUse:Bash hook — cmux send/set-buffer 감지 시 display-message

# jq로 tool_input.command 파싱
INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // ""' 2>/dev/null)

# cmux send 또는 set-buffer 감지
if echo "$COMMAND" | grep -qE 'cmux (send|set-buffer|paste-buffer)'; then
  # surface 번호 추출
  SURFACE=$(echo "$COMMAND" | grep -oE 'surface:[0-9]+' | head -1)

  if [ -n "$SURFACE" ]; then
    # 와쳐에 알림 (비동기, 실패해도 무시)
    cmux display-message "📡 작업 전송: $SURFACE" 2>/dev/null &
  fi
fi

# 항상 approve (차단하지 않음)
echo '{"decision":"approve"}'
