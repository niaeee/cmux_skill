#!/usr/bin/env python3
"""cmux-init-enforcer.py — PreToolUse:Bash Hook (L0 BLOCK)

Claude Code surface(GLM/MiniMax)에 작업 전송 전 /new 초기화 여부 강제.
Codex CLI surface는 초기화 불필요.

동작:
1. cmux send "/new" 감지 → 초기화 완료 기록
2. cmux set-buffer --surface (워커) 감지 → 해당 surface가 초기화됐는지 확인
3. 미초기화 시 BLOCK (Codex surface 제외)
"""
import json
import os
import re
import sys
import time

STATE_FILE = "/tmp/cmux-init-state.json"
# Codex CLI surfaces (workspace:1 = S:1-4, workspace:5 = S:21-24)
CODEX_SURFACES = {"1", "2", "3", "4", "21", "22", "23", "24"}
WATCHER_SURFACE = "29"

def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass
    return {"initialized": {}}

def save_state(data):
    with open(STATE_FILE, "w") as f:
        json.dump(data, f)

def main():
    inp = json.loads(sys.stdin.read())
    if inp.get("tool_name") != "Bash":
        print(json.dumps({"decision": "approve"}))
        return

    command = inp.get("tool_input", {}).get("command", "")
    state = load_state()

    # /new 전송 감지 → 초기화 기록
    if '"/new"' in command or "'/new'" in command or ' /new' in command:
        m = re.search(r'surface[: ]+(\d+)', command)
        if m:
            state["initialized"][m.group(1)] = time.time()
            save_state(state)

    # set-buffer 감지 → 초기화 여부 확인
    if "set-buffer" in command and "--surface" in command:
        m = re.search(r'surface:(\d+)', command)
        if m:
            sid = m.group(1)
            # Codex와 와쳐는 초기화 불필요
            if sid in CODEX_SURFACES or sid == WATCHER_SURFACE:
                print(json.dumps({"decision": "approve"}))
                return
            # Claude Code surface — 초기화 확인
            init_time = state.get("initialized", {}).get(sid, 0)
            if time.time() - init_time > 600:  # 10분 이내 초기화 필요
                print(json.dumps({
                    "decision": "block",
                    "reason": f"[INIT-ENFORCER] ⛔ surface:{sid}(Claude Code)에 /new 초기화 없이 작업 전송 시도. 먼저 Esc → /new → enter → sleep 3 실행하세요."
                }))
                return

    print(json.dumps({"decision": "approve"}))

if __name__ == "__main__":
    main()
