#!/bin/bash
# cmux-main-context.sh — UserPromptSubmit hook
# /cmux 입력 시 와쳐 캐시 + roles를 AI context에 강제 주입
# enforcer는 세션 시작 시 1회만 → /cmux 시점엔 와쳐 정보 없을 수 있음

PAYLOAD=$(cat)
[ -n "${CMUX_WORKSPACE_ID:-}" ] || exit 0

USER_MSG=$(echo "$PAYLOAD" | python3 -c "import json,sys; print(json.loads(sys.stdin.read()).get('message',''))" 2>/dev/null)

# /cmux만 매칭 (/cmux-watcher 제외)
echo "$USER_MSG" | grep -qE "^/cmux$|^/cmux " || exit 0
echo "$USER_MSG" | grep -qi "watcher" && exit 0

# 캐시 + roles 읽어서 주입
python3 -c "
import json, os, time

scan_file = '/tmp/cmux-surface-scan.json'
roles_file = '/tmp/cmux-roles.json'

surfaces = {}
roles = {}
scan_age = 999

if os.path.exists(scan_file):
    scan_age = time.time() - os.path.getmtime(scan_file)
    if scan_age < 300:
        try: surfaces = json.load(open(scan_file)).get('surfaces', {})
        except: pass

if os.path.exists(roles_file):
    try: roles = json.load(open(roles_file))
    except: pass

watcher = roles.get('watcher', {}).get('surface', '미등록')
main = roles.get('main', {}).get('surface', '미등록')
total = len(surfaces)

lines = []
for s, i in sorted(surfaces.items(), key=lambda x: int(x[0].split(':')[1])):
    lines.append(f'  {s} = {i.get(\"model\",\"?\")} ({i.get(\"status\",\"?\")}, {i.get(\"role\",\"?\")})')
summary = chr(10).join(lines[:20])

msg = f'[CMUX-MAIN] 와쳐 캐시 주입 (scan: {int(scan_age)}초 전)\\n와쳐: {watcher}\\n메인: {main}\\nsurface: {total}개\\n{summary}'

print(json.dumps({'hookSpecificOutput': {'hookEventName': 'UserPromptSubmit', 'additionalContext': msg}}, ensure_ascii=False))
" 2>/dev/null || exit 0
