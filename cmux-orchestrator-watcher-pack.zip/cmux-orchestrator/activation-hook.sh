#!/bin/bash
# cmux-orchestrator activation hook
# 스킬 로드 시 자동 실행 — Hook 심링크 + settings.json 등록
# 다른 AI가 이 스킬을 설치/로드할 때 자동으로 강제 수단이 활성화됨

set -e

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOKS_SOURCE="$SKILL_DIR/hooks"
HOOKS_TARGET="$HOME/.claude/hooks"
SETTINGS="$HOME/.claude/settings.json"
INSTALL_FLAG="/tmp/cmux-orch-hooks-installed.flag"

# 이미 이번 세션에서 설치했으면 스킵 (성능)
if [ -f "$INSTALL_FLAG" ]; then
    flag_age=$(( $(date +%s) - $(stat -f %m "$INSTALL_FLAG" 2>/dev/null || stat -c %Y "$INSTALL_FLAG" 2>/dev/null || echo 0) ))
    if [ "$flag_age" -lt 3600 ]; then
        exit 0
    fi
fi

# Hook 디렉토리 없으면 설치할 것 없음
if [ ! -d "$HOOKS_SOURCE" ]; then
    exit 0
fi

mkdir -p "$HOOKS_TARGET"

# Step 1: 심링크 생성 (없는 것만)
installed=0
for f in "$HOOKS_SOURCE"/*.sh "$HOOKS_SOURCE"/*.py; do
    [ -f "$f" ] || continue
    fname=$(basename "$f")
    link="$HOOKS_TARGET/$fname"

    if [ ! -L "$link" ] && [ ! -f "$link" ]; then
        ln -s "$f" "$link"
        chmod +x "$f"
        installed=$((installed + 1))
    fi
done

# Watcher hooks도 처리
WATCHER_HOOKS="$HOME/.claude/skills/cmux-watcher/hooks"
if [ -d "$WATCHER_HOOKS" ]; then
    for f in "$WATCHER_HOOKS"/*.sh "$WATCHER_HOOKS"/*.py; do
        [ -f "$f" ] || continue
        fname=$(basename "$f")
        link="$HOOKS_TARGET/$fname"
        if [ ! -L "$link" ] && [ ! -f "$link" ]; then
            ln -s "$f" "$link"
            chmod +x "$f"
            installed=$((installed + 1))
        fi
    done
fi

# Step 2: settings.json 자동 등록 (없는 것만)
if [ -f "$SETTINGS" ] && command -v python3 >/dev/null 2>&1; then
    python3 - "$SETTINGS" << 'PYEOF'
import json, sys, os

settings_path = sys.argv[1]
with open(settings_path) as f:
    data = json.load(f)

if "hooks" not in data:
    data["hooks"] = {}
hooks = data["hooks"]

HOOK_MAP = {
    "cmux-init-enforcer.py": ("PreToolUse", "Bash", 3),
    "cmux-watcher-notify-enforcer.py": ("PreToolUse", "Bash", 3),
    "cmux-no-stall-enforcer.py": ("PreToolUse", "Bash|Agent", 3),
    "cmux-gate6-agent-block.sh": ("PreToolUse", "Agent", 5),
    "cmux-read-guard.sh": ("PreToolUse", "Bash", 5),
    "cmux-watcher-msg-guard.py": ("PreToolUse", "Bash", 3),
    "cmux-completion-verifier.py": ("PreToolUse", "Bash", 3),
    "cmux-workflow-state-machine.py": ("PreToolUse", "Bash|Agent", 3),
    "cmux-dispatch-notify.sh": ("PostToolUse", "Bash", 3),
    "cmux-idle-reuse-enforcer.py": ("PostToolUse", "Bash", 3),
    "cmux-setbuffer-fallback.py": ("PostToolUse", "Bash", 3),
    "cmux-enforcement-escalator.py": ("PostToolUse", "Bash|Agent", 3),
    "cmux-idle-reminder.sh": ("UserPromptSubmit", None, 5),
    "cmux-main-context.sh": ("UserPromptSubmit", None, 10),
    "cmux-stop-guard.sh": ("Stop", None, 5),
    "cmux-model-profile-hook.sh": ("SessionStart", None, 5),
    "cmux-hook-audit.sh": ("SessionStart", None, 5),
    "cmux-watcher-session.sh": ("SessionStart", None, 5),
    "cmux-watcher-activate.sh": ("UserPromptSubmit", None, 120),
}

added = 0
for filename, (event, matcher, timeout) in HOOK_MAP.items():
    if event not in hooks:
        hooks[event] = []
    if any(filename in h.get("command", "") for h in hooks[event]):
        continue
    ext = os.path.splitext(filename)[1]
    prefix = "python3" if ext == ".py" else "bash"
    entry = {"type": "command", "command": f"{prefix} ~/.claude/hooks/{filename}", "timeout": timeout}
    if matcher:
        entry["matcher"] = matcher
    hooks[event].append(entry)
    added += 1

if added > 0:
    with open(settings_path, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
PYEOF
fi

# 설치 완료 플래그
touch "$INSTALL_FLAG"

exit 0
