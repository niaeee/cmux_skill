# cmux Multi-AI Orchestrator + Watcher Pack

**cmux** 환경에서 여러 AI surface를 오케스트레이션하고, 와쳐가 실시간으로 감시하는 Claude Code 스킬 패키지.

## 포함 스킬

| 스킬 | 역할 | 파일 수 |
|------|------|---------|
| **cmux-orchestrator** | Main AI가 워커 AI들에 작업 분배 + 결과 수집 + 커밋 | SKILL.md + 18 hooks + 27 scripts |
| **cmux-watcher** | 전 surface 실시간 감시 (IDLE/ERROR/DONE 감지 → Main에 알림) | SKILL.md + 2 hooks + 4 scripts |

## 전제 조건

- **cmux** 설치 필요 (tmux 기반 AI surface 관리 도구)
- **Claude Code** CLI (hooks 시스템 사용)
- **Python 3.10+** (Hook 스크립트 실행)
- macOS 또는 Linux

## 설치

### 방법 1: 자동 설치 (권장)

```bash
# 1. 압축 해제
unzip cmux-orchestrator-watcher-pack.zip -d ~/.claude/skills/

# 2. 설치 스크립트 실행
bash ~/.claude/skills/cmux-orchestrator/install.sh
```

설치 스크립트가 자동으로:
- `~/.claude/hooks/`에 18개 Hook 심링크 생성
- `~/.claude/settings.json`에 Hook 이벤트 자동 등록
- 실행 권한 부여
- 네거티브 테스트 실행 (12/12 PASS 확인)

### 방법 2: 스킬 로드 시 자동 설치

스킬이 Claude Code에 의해 로드되면 `activation-hook.sh`가 자동 실행되어 Hook을 설치합니다. 수동 작업 불필요.

### 제거

```bash
bash ~/.claude/skills/cmux-orchestrator/install.sh --uninstall
```

## 구조

```
cmux-orchestrator/
├── SKILL.md              # 오케스트레이션 규칙 (38KB)
├── activation-hook.sh    # 스킬 로드 시 자동 Hook 설치
├── install.sh            # 수동 설치/제거
├── hooks/                # 18개 강제 수단 (L0 BLOCK + L2 WARN)
│   ├── cmux-workflow-state-machine.py   # dispatch→verify→commit 순서 강제
│   ├── cmux-completion-verifier.py      # 커밋 전 기계적 검증 강제
│   ├── cmux-watcher-msg-guard.py        # 와쳐에 보고성 메시지 차단
│   ├── cmux-init-enforcer.py            # Claude Code surface 초기화 강제
│   ├── cmux-watcher-notify-enforcer.py  # 디스패치 후 와쳐 알림 강제
│   ├── cmux-no-stall-enforcer.py        # 멈춤 방지 (Sonnet 검증 미투입 차단)
│   ├── cmux-enforcement-escalator.py    # 위반 3회 → L0 승격 권고
│   ├── cmux-setbuffer-fallback.py       # set-buffer 전송 실패 감지
│   ├── test-hooks-negative.sh           # 12개 네거티브 테스트
│   └── ... (9개 더)
└── scripts/              # 29개 실행 유틸리티
    ├── eagle_watcher.sh         # 텍스트 기반 surface 스캔
    ├── gate-enforcer.py         # GATE 검증
    ├── smart-dispatch.sh        # 작업 전송 + 검증
    ├── read-surface.sh          # workspace 자동 해석 surface 읽기
    └── ...

cmux-watcher/
├── SKILL.md              # 감시 규칙 (33KB)
├── activation-hook.sh    # 4계층 감시 자동 시작
├── hooks/
│   ├── cmux-watcher-activate.sh  # 와쳐 활성화
│   └── cmux-watcher-session.sh   # 세션 시작 시 와쳐 등록
└── scripts/
    ├── watcher-scan.py          # 통합 스캐너 + 알림 생성
    ├── surface-monitor.py       # 4계층 감지 (Eagle+OCR+VisionDiff+pipe-pane)
    ├── surface-monitor.sh       # surface 상태 판정
    └── vision-stall-detector.py # ANE OCR 기반 멈춤 감지
```

## 강제력 체계 (Hook Enforcement Pyramid)

AI는 프롬프트 지침(L3)을 무시합니다. 이 패키지는 L0 물리적 차단으로 강제합니다.

```
L0 ████████ PreToolUse BLOCK — 9개 (도구 실행 자체를 차단, 우회 불가)
L1 ████     PostToolUse BLOCK — 사후 검증 차단
L2 ████     PostToolUse WARN — 경고 주입 + 자동 승격
L3          SKILL.md — 프롬프트 (무시 가능 ⚠️)
```

### 주요 강제 규칙

| 규칙 | 레벨 | Hook | 효과 |
|------|------|------|------|
| 검증 없이 커밋 금지 | L0 | completion-verifier.py | `touch /tmp/cmux-verification-passed` 후에만 commit 허용 |
| dispatch→verify→commit 순서 | L0 | workflow-state-machine.py | 상태 전이 위반 시 차단 |
| 와쳐에 보고 메시지 금지 | L0 | watcher-msg-guard.py | 감시 지시만 허용, 성과 보고 차단 |
| Claude Code 초기화 강제 | L0 | init-enforcer.py | /new 없이 작업 전송 차단 |
| 디스패치 후 와쳐 알림 강제 | L0 | watcher-notify-enforcer.py | 알림 누락 시 다음 작업 차단 |
| 멈춤 방지 | L0 | no-stall-enforcer.py | Sonnet 검증 미투입 + IDLE 방치 차단 |
| 위반 자동 승격 | L2 | enforcement-escalator.py | 같은 위반 3회 → L0 승격 권고 |
| set-buffer 실패 감지 | L2 | setbuffer-fallback.py | 전송 실패 시 cmux send fallback 제안 |

## 네거티브 테스트

```bash
bash cmux-orchestrator/hooks/test-hooks-negative.sh
```

12개 테스트 항목:
- git commit 검증 없이 → BLOCK 확인
- git commit 검증 후 → APPROVE 확인
- 와쳐에 성과 보고 → BLOCK 확인
- 와쳐에 감시 지시 → APPROVE 확인
- Claude Code 초기화 없이 → BLOCK 확인
- Codex surface 초기화 없이 → APPROVE 확인 (불필요)
- 상태 기계 IDLE에서 커밋 → BLOCK 확인
- 상태 기계 VERIFIED에서 커밋 → APPROVE 확인

## cmux 환경 구성 예시

```
사장실 (workspace:4)
├── Main AI (Opus) — 오케스트레이터
└── Watcher AI — 감시 전담

코덱스 (workspace:1)
├── Codex CLI surface × 4 — 중상급 코드 구현

GLM (workspace:2)
├── Claude Code (GLM) × 2 — 중하급 구현

MiniMax (workspace:3)
├── Claude Code (MiniMax) × 4 — 중하급 구현
```

## 라이선스

MIT License

## 변경 이력

- **v4.1** (2026-03-27): IDLE debounce, 7개 신규 Hook, 12개 네거티브 테스트, 상태 기계 워크플로우, 강제력 자동 승격
- **v4.0** (2026-03-27): 4계층 감시 (Eagle+OCR+VisionDiff+pipe-pane), adaptive polling, STALLED 전환
- **v7.4** (2026-03-26): GATE 1-11, dual-monitor, smart-dispatch
