#!/bin/bash
# surface-dispatcher.sh v6 — 버그 수정 3종:
#   1. 글리프(✻✶✽) 잔여 필터링으로 ACTIVE 오판 방지
#   2. --workspace workspace:N 지원으로 타 surface 상태 읽기
#   3. DONE 감지 확장 (최근 10줄优先 + 전체 fallback)

SURFACES="${1:-39 32 41 42 43 44 27 38}"
WORKSPACE="${WORKSPACE:-default}"
REPORT=""

for S in $SURFACES; do
    # v6: workspace는 현재 workspace가 기본값이므로 surface만 지정
    # (다른 workspace의 surface 읽을 때만 --workspace 추가)
    if [ "$WORKSPACE" = "default" ]; then
        SCREEN=$(cmux read-screen --surface "surface:${S}" --lines 30 2>/dev/null) || SCREEN=""
    else
        SCREEN=$(cmux read-screen --workspace "$WORKSPACE" --surface "surface:${S}" --lines 30 2>/dev/null) || SCREEN=""
    fi

    # ── 빈 스크린 방지 ──
    if [ -z "$SCREEN" ]; then
        REPORT="${REPORT}S:${S}=ERR "
        continue
    fi

    # ── 글리프 필터링 (ACTIVE 판정 전 선행) ──
    SCREEN_CLEAN=$(echo "$SCREEN" | sed 's/✻/ /g; s/✶/ /g; s/✽/ /g; s/✢/ /g; s/✳/ /g; s/⏺/ /g; s/·/ /g')

    # ── DONE 감지 (최근 10줄优先 + 전체 fallback) ──
    LAST10=$(echo "$SCREEN_CLEAN" | tail -n 10)
    REAL_DONE=0
    if echo "$LAST10" | grep -qE "^\s*DONE\s*$"; then
        REAL_DONE=1
    elif echo "$SCREEN_CLEAN" | grep -qE "^\s*DONE\s*$"; then
        # 전체에서 발견하면 fallback (최근 10줄에 없을 때)
        REAL_DONE=1
    fi

    # ── 상태 판정 ──
    if [ "$REAL_DONE" -ge 1 ]; then
        STATUS="DONE"
    elif echo "$SCREEN" | grep -q "Press up to edit queued"; then
        STATUS="QUEUED"
    elif echo "$SCREEN" | grep -qE "until auto-compact|until auto-co"; then
        STATUS="COMPACT!"
    elif echo "$SCREEN_CLEAN" | grep -qE "429|Usage limit|Rate limit"; then
        STATUS="RATE_LIM"
    elif echo "$SCREEN_CLEAN" | grep -qE "thinking|thought|tokens|esc to interrupt"; then
        T=$(echo "$SCREEN_CLEAN" | grep -oE "[0-9]+m" | head -1 | tr -d 'm')
        T=${T:-0}
        STATUS="WORK(${T}m)"
    elif echo "$SCREEN_CLEAN" | grep -qE "(Churned|Cooked|Baked|Sautéed|Cogitated|Crunched|Brewed|Worked) for [0-9]+m"; then
        T=$(echo "$SCREEN_CLEAN" | grep -oE "[0-9]+m" | head -1 | tr -d 'm')
        T=${T:-0}
        STATUS="ENDED(${T}m)"
    elif echo "$SCREEN_CLEAN" | grep -qE "• Working|⏺ Working|Working \([0-9]+[ms]"; then
        T=$(echo "$SCREEN_CLEAN" | grep -oE "[0-9]+m" | head -1 | tr -d 'm')
        T=${T:-0}
        STATUS="WORK(${T}m)"
    elif echo "$SCREEN_CLEAN" | grep -qE "[A-Za-z]+\s+[0-9]+m\s+[0-9]+s"; then
        T=$(echo "$SCREEN_CLEAN" | grep -oE "[0-9]+m" | head -1 | tr -d 'm')
        T=${T:-0}
        STATUS="ACTIVE(${T}m)"
    else
        STATUS="IDLE"
    fi

    REPORT="${REPORT}S:${S}=${STATUS} "
done

echo "$REPORT"
