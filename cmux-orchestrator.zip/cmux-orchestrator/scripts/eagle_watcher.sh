#!/bin/bash
# eagle_watcher.sh — multi-workspace cmux surface watcher
#
# Requirements:
# - Run with bash, avoid mapfile for zsh-friendly usage patterns
# - Parse `cmux tree --all` text output to map every workspace:surface
# - Probe each surface with `cmux read-screen --workspace ... --surface ... --lines 5`
# - Write JSON to /tmp/cmux-eagle-status.json

set -u

variable_status_file="${EAGLE_STATUS_FILE:-/tmp/cmux-eagle-status.json}"
variable_interval="${EAGLE_INTERVAL:-20}"
variable_once=false

variable_script_dir="$(cd "$(dirname "$0")" && pwd)"
variable_skill_dir="${SKILL_DIR:-$(dirname "$variable_script_dir")}"
variable_config_file="${variable_skill_dir}/config/orchestra-config.json"

for variable_arg in "$@"; do
  case "$variable_arg" in
    --once)
      variable_once=true
      ;;
  esac
done

function_append_surface_id() {
  local variable_current="$1"
  local variable_sid="$2"

  if [ -z "$variable_current" ]; then
    printf '%s' "$variable_sid"
  else
    printf '%s %s' "$variable_current" "$variable_sid"
  fi
}

function_compact_text() {
  printf '%s' "$1" \
    | tr '\011\015\012' '   ' \
    | tr -d '\000-\010\013\014\016-\037' \
    | sed 's/[[:space:]][[:space:]]*/ /g; s/^ //; s/ $//'
}

function_find_session_snapshot_file() {
  local variable_session_file=""

  if [ -n "${EAGLE_SESSION_FILE:-}" ] && [ -f "${EAGLE_SESSION_FILE}" ]; then
    printf '%s\n' "${EAGLE_SESSION_FILE}"
    return 0
  fi

  variable_session_file="${HOME}/Library/Application Support/cmux/session-com.cmuxterm.app.json"
  if [ -f "$variable_session_file" ]; then
    printf '%s\n' "$variable_session_file"
    return 0
  fi

  return 1
}

function_read_tree_output() {
  if [ -n "${EAGLE_TREE_FILE:-}" ] && [ -f "${EAGLE_TREE_FILE}" ]; then
    cat "${EAGLE_TREE_FILE}"
    return 0
  fi

  if ! command -v cmux >/dev/null 2>&1; then
    echo "cmux not found"
    return 127
  fi

  cmux tree --all 2>&1
}

function_detect_surfaces() {
  local variable_mapping_file="$1"
  local variable_tree_file="$2"
  local variable_current_workspace=""
  local variable_line=""
  local variable_workspace_ref=""
  local variable_surface_ref=""
  local variable_surface_id=""
  local variable_title=""

  : > "$variable_mapping_file"

  while IFS= read -r variable_line; do
    variable_workspace_ref=$(printf '%s\n' "$variable_line" | sed -n 's/.*\(workspace:[0-9][0-9]*\).*/\1/p')
    if [ -n "$variable_workspace_ref" ]; then
      variable_current_workspace="$variable_workspace_ref"
    fi

    variable_surface_ref=$(printf '%s\n' "$variable_line" | sed -n 's/.*\(surface:[0-9][0-9]*\).*/\1/p')
    [ -n "$variable_surface_ref" ] || continue
    [ -n "$variable_current_workspace" ] || continue

    variable_surface_id="${variable_surface_ref#surface:}"
    variable_title=$(printf '%s\n' "$variable_line" | sed -n 's/.*"\([^"]*\)".*/\1/p')
    variable_title=$(function_compact_text "$variable_title")

    if awk -F '\t' -v sid="$variable_surface_id" '$1 == sid { found=1 } END { exit(found ? 0 : 1) }' "$variable_mapping_file" 2>/dev/null; then
      continue
    fi

    printf '%s\t%s\t%s\t%s\n' \
      "$variable_surface_id" \
      "$variable_current_workspace" \
      "$variable_surface_ref" \
      "$variable_title" >> "$variable_mapping_file"
  done < "$variable_tree_file"
}

function_read_surface_screen() {
  local variable_workspace_ref="$1"
  local variable_surface_ref="$2"

  cmux read-screen \
    --workspace "$variable_workspace_ref" \
    --surface "$variable_surface_ref" \
    --lines 5 2>&1
}

function_detect_status() {
  local variable_screen="$1"
  local variable_clean=""

  variable_clean=$(printf '%s\n' "$variable_screen" | tr -d '\000-\010\013\014\016-\037' | sed 's/\r//g')

  if [ -z "$(printf '%s' "$variable_clean" | tr -d '[:space:]')" ]; then
    echo "UNKNOWN"
    return
  fi

  if printf '%s\n' "$variable_clean" | grep -qiE "Would you like|Do you want|Shall I|confirm|proceed\\?|continue\\?|\\[Y/n\\]|\\[y/N\\]"; then
    echo "WAITING"
  elif printf '%s\n' "$variable_clean" | grep -qiE "invalid_params|Operation not permitted|Failed to connect|rate limit|quota|insufficient.balance|authentication.failed|unauthorized|overloaded|Bad Gateway|Service Unavailable|timed out|timeout|ECONNREFUSED|No such file or directory|not found"; then
    echo "ERROR"
  elif printf '%s\n' "$variable_clean" | grep -qiE "gpt-5.4|esc to interrupt|thinking|auto-compact|Press up to edit queued|⠋|⠙|⠹|⠸|⠼|⠴|⠦|⠧|⠇|⠏|Working"; then
    echo "WORKING"
  elif printf '%s\n' "$variable_clean" | grep -qiE "^[[:space:]]*DONE[[:space:]]*$|(Brewed|Cooked|Churned|Baked|Cogitated|Crunched|Worked|Completed|Finished)"; then
    echo "DONE"
  else
    echo "IDLE"
  fi
}

function_extract_snippet() {
  local variable_screen="$1"
  local variable_snippet=""

  variable_snippet=$(
    printf '%s\n' "$variable_screen" \
      | tr -d '\000-\010\013\014\016-\037' \
      | sed 's/\r//g' \
      | sed '/^[[:space:]]*$/d' \
      | tail -n 1
  )
  variable_snippet=$(function_compact_text "$variable_snippet")
  printf '%s' "$(printf '%s' "$variable_snippet" | cut -c1-120)"
}

function_write_status_json() {
  local variable_rows_file="$1"
  local variable_idle_list="$2"
  local variable_working_list="$3"
  local variable_done_list="$4"
  local variable_waiting_list="$5"
  local variable_error_list="$6"
  local variable_error_message="$7"
  local variable_timestamp="$8"
  local variable_output_file="$9"

  python3 - "$variable_rows_file" "$variable_config_file" "$variable_idle_list" "$variable_working_list" "$variable_done_list" "$variable_waiting_list" "$variable_error_list" "$variable_error_message" "$variable_timestamp" > "$variable_output_file" <<'PY'
import json
import os
import sys

rows_file = sys.argv[1]
config_file = sys.argv[2]
idle_list = sys.argv[3]
working_list = sys.argv[4]
done_list = sys.argv[5]
waiting_list = sys.argv[6]
error_list = sys.argv[7]
error_message = sys.argv[8]
timestamp = sys.argv[9]

ai_map = {}
if config_file and os.path.isfile(config_file):
    try:
        with open(config_file, encoding="utf-8") as fh:
            config = json.load(fh)
        for sid, info in config.get("surfaces", {}).items():
            ai_map[str(sid)] = info.get("ai", "unknown")
    except Exception:
        ai_map = {}

surfaces = {}
if os.path.isfile(rows_file):
    with open(rows_file, encoding="utf-8") as fh:
        for raw in fh:
            raw = raw.rstrip("\n")
            if not raw:
                continue
            parts = raw.split("\t")
            while len(parts) < 6:
                parts.append("")
            sid, workspace, surface, title, status, snippet = parts[:6]
            surfaces[sid] = {
                "workspace": workspace,
                "surface": surface,
                "status": status,
                "title": title,
                "ai": ai_map.get(sid, "unknown"),
                "snippet": snippet,
            }

def count_ids(value: str) -> int:
    value = value.strip()
    if not value:
        return 0
    return len(value.split())

payload = {
    "timestamp": timestamp,
    "surfaces": surfaces,
    "idle_surfaces": idle_list,
    "working_surfaces": working_list,
    "done_surfaces": done_list,
    "waiting_surfaces": waiting_list,
    "error_surfaces": error_list,
    "stats": {
        "total": len(surfaces),
        "idle": count_ids(idle_list),
        "working": count_ids(working_list),
        "done": count_ids(done_list),
        "waiting": count_ids(waiting_list),
        "error": count_ids(error_list),
        "unknown": sum(1 for info in surfaces.values() if info.get("status") == "UNKNOWN"),
    },
}

if error_message:
    payload["error"] = error_message

print(json.dumps(payload, ensure_ascii=False))
PY
}

function_write_session_fallback_status_json() {
  local variable_session_file="$1"
  local variable_error_message="$2"
  local variable_timestamp="$3"
  local variable_output_file="$4"

  python3 - "$variable_session_file" "$variable_config_file" "$variable_error_message" "$variable_timestamp" > "$variable_output_file" <<'PY'
import json
import os
import re
import sys

session_file = sys.argv[1]
config_file = sys.argv[2]
error_message = sys.argv[3]
timestamp = sys.argv[4]

with open(session_file, encoding="utf-8") as fh:
    session = json.load(fh)

config = {}
if config_file and os.path.isfile(config_file):
    try:
        with open(config_file, encoding="utf-8") as fh:
            config = json.load(fh)
    except Exception:
        config = {}

workspace_defs = config.get("workspaces", {})
surface_defs = config.get("surfaces", {})
main_surface = str(config.get("main_surface", "1") or "1")

windows = session.get("windows", [])
tab_manager = windows[0].get("tabManager", {}) if windows else {}
workspaces = tab_manager.get("workspaces", [])

group_defs = []
for group_key, group_info in workspace_defs.items():
    surface_ids = [str(value) for value in group_info.get("surfaces", [])]
    group_defs.append(
        {
            "key": group_key,
            "name": group_info.get("name", group_key),
            "ai": group_info.get("ai", "unknown"),
            "surfaces": surface_ids,
        }
    )

remaining_groups = {group["key"]: group for group in group_defs}
assignments = {}


def normalize(text):
    return (text or "").strip().lower()


def match_group_by_ai(expected_ai):
    expected = normalize(expected_ai)
    if not expected:
        return None
    for group in group_defs:
        if group["key"] not in remaining_groups:
            continue
        if normalize(group.get("ai")) == expected:
            return group
    return None


def choose_group(target_count):
    if not remaining_groups:
        return None
    target = max(int(target_count), 0)
    ordered = sorted(
        remaining_groups.values(),
        key=lambda group: (
            abs(len(group.get("surfaces", [])) - target),
            len(group.get("surfaces", [])),
            group.get("key", ""),
        ),
    )
    return ordered[0] if ordered else None


for workspace_index, workspace_info in enumerate(workspaces, 1):
    process_title = normalize(workspace_info.get("processTitle"))
    matched_group = None

    if "codex" in process_title:
        matched_group = match_group_by_ai("codex")
    elif re.search(r"(^|[^a-z])(ccg|glm)([^a-z]|$)", process_title):
        matched_group = match_group_by_ai("glm")

    if matched_group is not None:
        assignments[workspace_index] = matched_group
        remaining_groups.pop(matched_group["key"], None)

if workspaces:
    main_workspace_index = 1
    if main_workspace_index not in assignments:
        main_workspace = workspaces[main_workspace_index - 1]
        matched_group = choose_group(len(main_workspace.get("panels", [])) - 1)
        if matched_group is not None:
            assignments[main_workspace_index] = matched_group
            remaining_groups.pop(matched_group["key"], None)

for workspace_index, workspace_info in enumerate(workspaces, 1):
    if workspace_index in assignments:
        continue
    matched_group = choose_group(len(workspace_info.get("panels", [])))
    if matched_group is not None:
        assignments[workspace_index] = matched_group
        remaining_groups.pop(matched_group["key"], None)

used_surface_ids = set()
synthetic_candidate = 1
reserved_surface_ids = {str(key) for key in surface_defs.keys()}
reserved_surface_ids.add(main_surface)


def allocate_surface_ids(workspace_index, panel_count):
    global synthetic_candidate
    group = assignments.get(workspace_index)
    proposed = []

    if workspace_index == 1 and main_surface not in used_surface_ids:
        proposed.append(main_surface)

    if group is not None:
        for sid in group.get("surfaces", []):
            if sid not in proposed:
                proposed.append(sid)

    assigned = []
    for sid in proposed:
        if len(assigned) >= panel_count:
            break
        if sid in used_surface_ids:
            continue
        assigned.append(sid)
        used_surface_ids.add(sid)

    while len(assigned) < panel_count:
        while (
            str(synthetic_candidate) in used_surface_ids
            or str(synthetic_candidate) in reserved_surface_ids
        ):
            synthetic_candidate += 1
        sid = str(synthetic_candidate)
        synthetic_candidate += 1
        assigned.append(sid)
        used_surface_ids.add(sid)

    return assigned


def status_from_panel(panel_info):
    title = panel_info.get("customTitle") or panel_info.get("title") or ""
    match = re.search(r":([A-Z]+)$", title.strip())
    status = match.group(1) if match else ""
    if status in {"IDLE", "WORKING", "DONE", "WAITING", "ERROR", "UNKNOWN"}:
        return status
    return "UNKNOWN"


def compact_text(value):
    text = (value or "").replace("\r", " ").replace("\n", " ").strip()
    text = re.sub(r"\s+", " ", text)
    return text


surfaces = {}
idle = []
working = []
done = []
waiting = []
error = []

for workspace_index, workspace_info in enumerate(workspaces, 1):
    panels = [panel for panel in workspace_info.get("panels", []) if panel.get("type") == "terminal"]
    assigned_ids = allocate_surface_ids(workspace_index, len(panels))
    group = assignments.get(workspace_index, {})
    fallback_ai = group.get("ai", "unknown")

    for offset, panel in enumerate(panels):
        sid = assigned_ids[offset]
        status = status_from_panel(panel)
        title = compact_text(panel.get("customTitle") or panel.get("title") or fallback_ai)
        snippet = compact_text(
            " | ".join(
                part for part in [
                    workspace_info.get("processTitle", ""),
                    panel.get("directory", ""),
                ] if part
            )
        )[:120]

        if sid in surface_defs:
            ai_value = surface_defs.get(sid, {}).get("ai", fallback_ai)
        else:
            ai_value = fallback_ai

        surfaces[sid] = {
            "workspace": f"workspace:{workspace_index}",
            "surface": f"surface:{sid}",
            "status": status,
            "title": title,
            "ai": ai_value or "unknown",
            "snippet": snippet,
        }

        if status == "IDLE":
            idle.append(sid)
        elif status == "WORKING":
            working.append(sid)
        elif status == "DONE":
            done.append(sid)
        elif status == "WAITING":
            waiting.append(sid)
        elif status == "ERROR":
            error.append(sid)

payload = {
    "timestamp": timestamp,
    "surfaces": surfaces,
    "idle_surfaces": " ".join(idle),
    "working_surfaces": " ".join(working),
    "done_surfaces": " ".join(done),
    "waiting_surfaces": " ".join(waiting),
    "error_surfaces": " ".join(error),
    "stats": {
        "total": len(surfaces),
        "idle": len(idle),
        "working": len(working),
        "done": len(done),
        "waiting": len(waiting),
        "error": len(error),
        "unknown": sum(1 for info in surfaces.values() if info.get("status") == "UNKNOWN"),
    },
}

if error_message:
    payload["error"] = f"{error_message} (session snapshot fallback)"

print(json.dumps(payload, ensure_ascii=False))
PY
}

function_poll_once() {
  local variable_tree_file=""
  local variable_mapping_file=""
  local variable_rows_file=""
  local variable_output_file=""
  local variable_tree_output=""
  local variable_tree_error=""
  local variable_tree_exit=0
  local variable_idle_list=""
  local variable_working_list=""
  local variable_done_list=""
  local variable_waiting_list=""
  local variable_error_list=""
  local variable_timestamp=""
  local variable_sid=""
  local variable_workspace_ref=""
  local variable_surface_ref=""
  local variable_title=""
  local variable_screen_output=""
  local variable_screen_exit=0
  local variable_status=""
  local variable_snippet=""
  local variable_session_file=""

  variable_tree_file="$(mktemp /tmp/eagle-watcher-tree.XXXXXX)"
  variable_mapping_file="$(mktemp /tmp/eagle-watcher-map.XXXXXX)"
  variable_rows_file="$(mktemp /tmp/eagle-watcher-rows.XXXXXX)"
  variable_output_file="$(mktemp /tmp/eagle-watcher-json.XXXXXX)"

  variable_tree_output=$(function_read_tree_output)
  variable_tree_exit=$?
  printf '%s\n' "$variable_tree_output" > "$variable_tree_file"

  if [ "$variable_tree_exit" -ne 0 ]; then
    variable_tree_error=$(function_compact_text "$variable_tree_output")
    if variable_session_file=$(function_find_session_snapshot_file); then
      variable_timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
      if function_write_session_fallback_status_json \
        "$variable_session_file" \
        "$variable_tree_error" \
        "$variable_timestamp" \
        "$variable_output_file"; then
        mv "$variable_output_file" "$variable_status_file"
        rm -f "$variable_tree_file" "$variable_mapping_file" "$variable_rows_file"
        return
      fi
    fi
  fi

  function_detect_surfaces "$variable_mapping_file" "$variable_tree_file"

  if [ ! -s "$variable_mapping_file" ] && variable_session_file=$(function_find_session_snapshot_file); then
    variable_timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    if function_write_session_fallback_status_json \
      "$variable_session_file" \
      "$variable_tree_error" \
      "$variable_timestamp" \
      "$variable_output_file"; then
      mv "$variable_output_file" "$variable_status_file"
      rm -f "$variable_tree_file" "$variable_mapping_file" "$variable_rows_file"
      return
    fi
  fi

  : > "$variable_rows_file"

  while IFS=$'\t' read -r variable_sid variable_workspace_ref variable_surface_ref variable_title; do
    [ -n "${variable_sid:-}" ] || continue

    variable_screen_output=$(function_read_surface_screen "$variable_workspace_ref" "$variable_surface_ref")
    variable_screen_exit=$?
    variable_status=$(function_detect_status "$variable_screen_output")

    if [ "$variable_screen_exit" -ne 0 ] && [ "$variable_status" = "IDLE" -o "$variable_status" = "UNKNOWN" ]; then
      variable_status="ERROR"
    fi

    variable_snippet=$(function_extract_snippet "$variable_screen_output")
    variable_title=$(function_compact_text "$variable_title")

    printf '%s\t%s\t%s\t%s\t%s\t%s\n' \
      "$variable_sid" \
      "$variable_workspace_ref" \
      "$variable_surface_ref" \
      "$variable_title" \
      "$variable_status" \
      "$variable_snippet" >> "$variable_rows_file"

    case "$variable_status" in
      IDLE)
        variable_idle_list=$(function_append_surface_id "$variable_idle_list" "$variable_sid")
        ;;
      WORKING)
        variable_working_list=$(function_append_surface_id "$variable_working_list" "$variable_sid")
        ;;
      DONE)
        variable_done_list=$(function_append_surface_id "$variable_done_list" "$variable_sid")
        ;;
      WAITING)
        variable_waiting_list=$(function_append_surface_id "$variable_waiting_list" "$variable_sid")
        ;;
      ERROR)
        variable_error_list=$(function_append_surface_id "$variable_error_list" "$variable_sid")
        ;;
    esac
  done < "$variable_mapping_file"

  variable_timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  function_write_status_json \
    "$variable_rows_file" \
    "$variable_idle_list" \
    "$variable_working_list" \
    "$variable_done_list" \
    "$variable_waiting_list" \
    "$variable_error_list" \
    "$variable_tree_error" \
    "$variable_timestamp" \
    "$variable_output_file"

  mv "$variable_output_file" "$variable_status_file"

  rm -f "$variable_tree_file" "$variable_mapping_file" "$variable_rows_file"
}

if [ "$variable_once" = true ]; then
  function_poll_once
  cat "$variable_status_file"
else
  while true; do
    function_poll_once
    sleep "$variable_interval"
  done
fi
