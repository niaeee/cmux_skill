#!/bin/bash
# ============================================================================
# cmux-orchestrator 설치 스크립트 v7.2
# 멀티 AI 오케스트레이션 스킬 for Claude Code + cmux
# ============================================================================
set -euo pipefail

variable_version="v7.2"
variable_src_dir="$(cd "$(dirname "$0")" && pwd)"
variable_skill_dst="${SKILL_INSTALL_DIR:-$HOME/.claude/skills/cmux-orchestrator}"
variable_agents_dst="$HOME/.claude/agents"
variable_settings_file="$HOME/.claude/settings.json"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

function_print_header() {
  echo ""
  echo -e "${BLUE}╔══════════════════════════════════════════════════════════╗${NC}"
  echo -e "${BLUE}║  cmux-orchestrator ${variable_version} — 멀티 AI 오케스트레이션     ║${NC}"
  echo -e "${BLUE}╚══════════════════════════════════════════════════════════╝${NC}"
  echo ""
}

function_check_prerequisites() {
  echo -e "${YELLOW}[1/5] 전제 조건 확인...${NC}"
  local variable_ok=true

  if command -v cmux &>/dev/null; then
    echo -e "  ${GREEN}✅ cmux 설치됨${NC}"
  else
    echo -e "  ${RED}❌ cmux 미설치${NC} → https://openclaw.ai"
    variable_ok=false
  fi

  if command -v claude &>/dev/null; then
    echo -e "  ${GREEN}✅ Claude Code 설치됨${NC}"
  else
    echo -e "  ${RED}❌ Claude Code 미설치${NC} → npm install -g @anthropic-ai/claude-code"
    variable_ok=false
  fi

  if command -v python3 &>/dev/null; then
    echo -e "  ${GREEN}✅ Python $(python3 --version 2>&1 | grep -oE '[0-9]+\.[0-9]+')${NC}"
  else
    echo -e "  ${RED}❌ Python 3 미설치${NC}"
    variable_ok=false
  fi

  if [ -f "$variable_settings_file" ]; then
    echo -e "  ${GREEN}✅ settings.json 존재${NC}"
  else
    echo -e "  ${YELLOW}⚠️  settings.json 미존재 — Claude Code를 한 번 실행해주세요${NC}"
  fi

  if [ "$variable_ok" = false ]; then
    echo ""
    echo -e "${RED}필수 조건 미충족. 위 항목 설치 후 다시 실행하세요.${NC}"
    exit 1
  fi
  echo ""
}

function_install_skill() {
  echo -e "${YELLOW}[2/5] 스킬 파일 설치...${NC}"

  if [ -d "$variable_skill_dst" ]; then
    local variable_backup="${variable_skill_dst}.bak.$(date +%Y%m%d%H%M%S)"
    echo -e "  ${YELLOW}⚠️  기존 설치 백업 → $(basename "$variable_backup")${NC}"
    mv "$variable_skill_dst" "$variable_backup"
  fi

  mkdir -p "$variable_skill_dst"
  cp "$variable_src_dir/SKILL.md" "$variable_skill_dst/"
  cp -r "$variable_src_dir/scripts" "$variable_skill_dst/"
  cp -r "$variable_src_dir/agents" "$variable_skill_dst/"
  cp -r "$variable_src_dir/references" "$variable_skill_dst/"
  cp -r "$variable_src_dir/commands" "$variable_skill_dst/"
  mkdir -p "$variable_skill_dst/config"

  # config: 기존 백업에 사용자 설정 있으면 유지
  local variable_old_config=""
  for d in "${variable_skill_dst}.bak."*; do
    [ -f "$d/config/orchestra-config.json" ] && variable_old_config="$d/config/orchestra-config.json"
  done
  if [ -n "$variable_old_config" ] && python3 -c "import json; d=json.load(open('$variable_old_config')); exit(0 if d.get('surfaces') else 1)" 2>/dev/null; then
    cp "$variable_old_config" "$variable_skill_dst/config/"
    echo -e "  ${GREEN}✅ 기존 orchestra-config.json 복원 (사용자 설정 유지)${NC}"
  else
    cp "$variable_src_dir/config/orchestra-config.json" "$variable_skill_dst/config/"
    echo -e "  ${GREEN}✅ 템플릿 orchestra-config.json 설치 (첫 실행 시 자동 구성)${NC}"
  fi

  rm -rf "$variable_skill_dst/scripts/__pycache__" 2>/dev/null
  echo -e "  ${GREEN}✅ $(find "$variable_skill_dst" -not -type d -not -name '.DS_Store' | wc -l | tr -d ' ')개 파일 설치 완료${NC}"
  echo ""
}

function_install_agents() {
  echo -e "${YELLOW}[3/5] 에이전트 설치...${NC}"
  mkdir -p "$variable_agents_dst"

  local variable_count=0
  for f in "$variable_skill_dst/agents"/*.md; do
    [ -f "$f" ] || continue
    local variable_name
    variable_name=$(basename "$f")
    cp "$f" "${variable_agents_dst}/${variable_name}"
    echo -e "  ${GREEN}✅ ${variable_name}${NC}"
    variable_count=$((variable_count + 1))
  done
  echo -e "  ${GREEN}${variable_count}개 에이전트 설치 완료${NC}"
  echo ""
}

function_set_permissions() {
  echo -e "${YELLOW}[4/5] 실행 권한 설정...${NC}"
  chmod +x "$variable_skill_dst/scripts"/*.sh 2>/dev/null
  echo -e "  ${GREEN}✅ scripts/*.sh chmod +x 완료${NC}"
  echo ""
}

function_install_hooks() {
  echo -e "${YELLOW}[5/5] Claude Code 훅 등록...${NC}"

  if [ ! -f "$variable_settings_file" ]; then
    echo -e "  ${YELLOW}⚠️  settings.json 미존재 — 나중에 bash install.sh --hooks-only 실행${NC}"
    return
  fi

  SKILL_DIR="$variable_skill_dst" python3 << 'PYEOF'
import json, sys, os

skill_dir = os.environ.get("SKILL_DIR", os.path.expanduser("~/.claude/skills/cmux-orchestrator"))
scripts_dir = os.path.join(skill_dir, "scripts")
settings_path = os.path.expanduser("~/.claude/settings.json")

if not os.path.exists(settings_path):
    print("  ⚠️  settings.json not found")
    sys.exit(0)

with open(settings_path) as f:
    s = json.load(f)

hooks = s.setdefault("hooks", {})
changed = False

HOOK_DEFS = [
    ("PreToolUse", "Bash", f"bash {scripts_dir}/gate-blocker.sh", 5, "GATE 커밋 차단"),
    ("PostToolUse", "Bash", f"python3 {scripts_dir}/gate-enforcer.py", 8, "GATE 경고"),
    ("SessionStart", None, f"bash {scripts_dir}/cmux-orchestra-enforcer.sh", 5, "자동 활성화"),
    ("SessionStart", None, f"bash {scripts_dir}/cmux-claude-bridge.sh session-start", 3, "cmux 브릿지"),
    ("UserPromptSubmit", None, f"bash {scripts_dir}/cmux-idle-reminder.sh", 5, "IDLE 알림"),
]

for event, matcher, command, timeout, desc in HOOK_DEFS:
    hook_list = hooks.setdefault(event, [])
    script_name = os.path.basename(command.split()[-1])
    already = any(script_name in json.dumps(entry) for entry in hook_list)
    if not already:
        entry = {"hooks": [{"type": "command", "command": command, "timeout": timeout}]}
        if matcher:
            entry["matcher"] = matcher
        hook_list.append(entry)
        changed = True
        print(f"  ✅ {event}: {desc} ({script_name})")
    else:
        print(f"  ⏭️  {event}: {desc} (이미 등록됨)")

if changed:
    with open(settings_path, "w") as f:
        json.dump(s, f, indent=2, ensure_ascii=False)
    print("  📝 settings.json 업데이트 완료")
else:
    print("  ✅ 모든 훅이 이미 등록되어 있습니다")
PYEOF
  echo ""
}

function_verify() {
  echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}설치 검증:${NC}"
  echo -e "  스킬:      $variable_skill_dst"
  echo -e "  에이전트:  $(find "$variable_agents_dst" -name 'cmux-*.md' 2>/dev/null | wc -l | tr -d ' ')개"
  echo -e "  스크립트:  $(find "$variable_skill_dst/scripts" -name '*.sh' -o -name '*.py' 2>/dev/null | wc -l | tr -d ' ')개"
  echo -e "  레퍼런스:  $(find "$variable_skill_dst/references" -name '*.md' 2>/dev/null | wc -l | tr -d ' ')개"

  if [ -f "$variable_settings_file" ]; then
    local variable_hc
    variable_hc=$(grep -c "gate-blocker\|gate-enforcer\|cmux-idle\|cmux-orchestra\|cmux-claude-bridge" "$variable_settings_file" 2>/dev/null || echo 0)
    echo -e "  훅:        ${variable_hc}개 항목"
  fi

  echo ""
  echo -e "${GREEN}✅ 설치 완료!${NC}"
  echo ""
  echo -e "${BLUE}다음 단계:${NC}"
  echo "  1. cmux에서 AI 창들을 열어주세요 (Codex, Gemini, GLM 등)"
  echo "  2. Claude Code에서 /cmux 또는 /cmux 초기화 실행"
  echo "  3. 자동으로 surface 감지 → AI 매핑 → 설정 저장 → 오케스트레이션 시작"
  echo ""
}

case "${1:---full}" in
  --full|--setup) function_print_header; function_check_prerequisites; function_install_skill; function_install_agents; function_set_permissions; function_install_hooks; function_verify ;;
  --hooks-only) echo -e "${YELLOW}훅만 등록...${NC}"; export SKILL_DIR="$variable_skill_dst"; function_install_hooks ;;
  --check) function_verify ;;
  --uninstall)
    echo -e "${RED}cmux-orchestrator 제거...${NC}"
    read -p "정말 제거? [y/N] " -n 1 -r; echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
      rm -rf "$variable_skill_dst"; rm -f "$variable_agents_dst"/cmux-*.md
      echo -e "${GREEN}제거 완료. settings.json 훅은 수동 제거 필요.${NC}"
    fi ;;
  --help|-h)
    echo "Usage: bash install.sh [--full|--hooks-only|--check|--uninstall|--help]"
    echo "  SKILL_INSTALL_DIR 환경변수로 설치 경로 변경 가능" ;;
  *) echo "알 수 없는 옵션: $1 (--help 참조)"; exit 1 ;;
esac
